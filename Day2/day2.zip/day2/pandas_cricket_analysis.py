import pandas as pd
import numpy as np
import datetime
import matplotlib.pyplot as plt
import seaborn as sns

df = pd.read_csv('MS_Dhoni_ODI_record.csv')
print(df.describe())
print(df.info())

# data cleaning: remove 'v ' from opposition column and get just the country name
df["opposition"] = df["opposition"].str.replace('v ', '', regex=False)
# df['opposition'] = df['opposition'].apply(lambda x: x[2:])  # same function as the above operation

# add a feature - 'year' column using the match 'date' column
df["date"] = pd.to_datetime(df['date'], dayfirst=True)
df['year'] = df['date'].dt.year.astype(int)
print(df['year'])

# batting average of ms dhoni in that match = total runs/(innings count-not out count)
# you can take the count of not outs using where and sum or just take count of a new column of 'not_out'
df["not_out"] = np.where(df['score'].str.endswith('*'), 1, 0)

# dropping columns that won't help with data analysis(here it is odi_number)
df.drop(columns='odi_number', inplace=True)

# creating a new df by dropping DNB and TDNB values in score and start with runs_scored
df_new = df.loc[((df['score'] != 'DNB') & (df['score'] != 'TDNB')), 'runs_scored':]  # second argument takes all columns after 'runs_scored'

# fixing data types of numerical columns
df_new['runs_scored'] = df_new['runs_scored'].astype(int)
df_new['balls_faced'] = df_new['balls_faced'].astype(int)
df_new['strike_rate'] = df_new['strike_rate'].astype(float)
df_new['fours'] = df_new['fours'].astype(int)
df_new['sixes'] = df_new['sixes'].astype(int)
# this is the end of the data cleaning phase
# print(df_new.info())
# print(df_new.head())
# print(df_new.tail())

# career stats of dhoniblud
first_match_date = df['date'].dt.date.min().strftime('%B %d, %Y')  # first match
print(f'First match date: {first_match_date}')
last_match_date = df['date'].dt.date.max().strftime('%B %d, %Y')  # last match
print(f'Last match date: {last_match_date}')

number_of_matches = df.shape[0]  # number of rows = matches played in his career
print(f'Number of total matches: {number_of_matches}')

number_of_innings = df_new.shape[0]  # taking new df where dnb and tdnb were removed
print(f'Number of innings: {number_of_innings}')

not_outs = df['not_out'].sum()  # number of not outs in career
print(f'Number of not outs in career: {not_outs}')

runs_scored = df_new['runs_scored'].sum()  # total career runs use df_new since dnb and tdnb have been removed from it
print(f'Total runs scored in career: {runs_scored}')

balls_faced = df_new['balls_faced'].sum()  # total balls faced

career_sr = (runs_scored / balls_faced)  # career strike rate
print(f'Total career strike rate: {career_sr:.3f}')

career_avg = (runs_scored / (number_of_innings - not_outs))  # career avg runs
print(f'Average runs scored per match: {career_avg:.3f}')

# for centuries scored
print(
    f"Centuries scored: {(df_new['runs_scored'] > 100).sum()}")  # (df_new['runs_scored']>100) is a boolean expression returning boolean vals in Series which satisfy the condition

# number of fours scored
print(f"Career fours scored: {df_new['fours'].sum()}")

# number of sixes scored
print(f"Career sixes scored: {df_new['sixes'].sum()}")

# highest score of career
print(f"Highest score of career: {df_new['runs_scored'].max()} runs against {df_new.loc[df_new['runs_scored'].idxmax(), 'opposition']}")

# visualization time
# number of matches played against different oppositions
# count occurrences of unique value in 'opposition' column
opposition_counts = df['opposition'].value_counts()
# plotting a bar graph
opposition_counts.plot(kind='bar', title='Number of matches against different oppositions', figsize=(8, 5))
plt.show()

# runs scored against each team by grouping dataframe by 'opposition' column
grouped_by_opposition = df_new.groupby('opposition')
# sum the 'runs_scored' column for each group
sum_of_runs_scored = grouped_by_opposition['runs_scored'].sum()
# sum_of_runs_scored is a series with opposition as index and runs as values. Convert it into a df and reset_index
runs_scored_by_opps = pd.DataFrame(sum_of_runs_scored).reset_index()
print(runs_scored_by_opps)
# plotting the graph
runs_scored_by_opps.plot(x='opposition', kind='bar', title='Runs scored against every team', figsize=(8, 5))
plt.show()


